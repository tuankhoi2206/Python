=======
Credits
=======

Development Lead
----------------

 * `mattmakai <https://github.com/mattmakai>`_

Contributors
------------

* `dhiatn <https://github.com/dhiatn>`_
* `mjhea0 <https://github.com/mjhea0>`_
* `haiiiiiyun <https://github.com/haiiiiiyun>`_
* `jllorencetti <https://github.com/jllorencetti>`_
* `monop <https://github.com/monop>`_
* `aoberoi <https://github.com/aoberoi>`_
* `proofit404 <https://github.com/proofit404>`_
* `flexd <https://github.com/flexd>`_
* `axd1967 <https://github.com/axd1967>`_
* `nullism <https://github.com/nullism>`_
* `ajschumacher <https://github.com/ajschumacher>`_
* `amol- <https://github.com/amol->`_
* `dhamaniasad <https://github.com/dhamaniasad>`_
* `Bogdanp <https://github.com/Bogdanp>`_
* `cenkalti <https://github.com/cenkalti>`_
* `ChristophKohl <https://github.com/ChristophKohl>`_
* `itsderek23 <https://github.com/itsderek23>`_
* `dolph <https://github.com/dolph>`_
* `luzfcb <https://github.com/luzfcb>`_
* `qgreg <https://github.com/qgreg>`_
* `TheJohnSub <https://github.com/TheJohnSub>`_
* `Jwpe <https://github.com/Jwpe>`_
* `kmarekspartz <https://github.com/kmarekspartz>`_
* `martey <https://github.com/martey>`_
* `MattKleinsmith <https://github.com/MattKleinsmith>`_
* `mattberjon <https://github.com/mattberjon>`_
* `oldhill <https://github.com/oldhill>`_
* `Parbhat <https://github.com/Parbhat>`_
* `rlaszlo <https://github.com/rlaszlo>`_
* `huangsam <https://github.com/huangsam>`_